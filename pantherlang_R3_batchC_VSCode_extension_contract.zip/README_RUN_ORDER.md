# R3 Batch C — VS Code Extension Contract

Run from PantherLang project root only:

```bash
cd /home/panther/pantherlang/PantherLang_Developer_Edition_v0_5
unzip pantherlang_R3_batchC_VSCode_extension_contract.zip
chmod +x bootstrap_R3_batchC_VSCode_extension_contract.sh
./bootstrap_R3_batchC_VSCode_extension_contract.sh
```

Targeted regression:

```bash
python3 -m pytest -q \
  tests/test_h4_4_d1_vscode_debugger_contribution.py \
  tests/test_h4_4_d2_debug_adapter_registration.py \
  tests/test_h4_4_d4_f5_debug_flow.py \
  tests/test_h4_4_d5_vscode_extension_package_verification.py \
  tests/test_h4_4_d6_vscode_end_to_end_verification.py
```

Then full regression:

```bash
python3 -m pytest -q
```
