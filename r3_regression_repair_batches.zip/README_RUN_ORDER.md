# PantherLang R3 Regression Repair Batches

Run these scripts from the PantherLang project root, in this exact order:

```bash
chmod +x bootstrap_R3_regression_repair_batch1_compiler_core.sh
./bootstrap_R3_regression_repair_batch1_compiler_core.sh

chmod +x bootstrap_R3_regression_repair_batch2_end_to_end_compiler.sh
./bootstrap_R3_regression_repair_batch2_end_to_end_compiler.sh

chmod +x bootstrap_R3_regression_repair_batch3_debug_adapter.sh
./bootstrap_R3_regression_repair_batch3_debug_adapter.sh
```

After Batch 3 passes, continue to:

R3 Batch 2 Part 3.3 - Expression Parser
