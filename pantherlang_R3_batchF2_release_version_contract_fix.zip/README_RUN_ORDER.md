# R3 Batch F2 — Release Version Contract Fix

Run from PantherLang repository root:

```bash
cd /home/panther/pantherlang/PantherLang_Developer_Edition_v0_5
unzip pantherlang_R3_batchF2_release_version_contract_fix.zip
chmod +x bootstrap_R3_batchF2_release_version_contract_fix.sh
./bootstrap_R3_batchF2_release_version_contract_fix.sh
python3 -m pytest -q
```
