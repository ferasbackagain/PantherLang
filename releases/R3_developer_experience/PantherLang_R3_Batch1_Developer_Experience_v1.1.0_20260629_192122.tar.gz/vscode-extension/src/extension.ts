import * as vscode from 'vscode';
import * as path from 'path';
import { startPantherF5Debug } from './debugFlow';

class PantherDebugAdapterDescriptorFactory implements vscode.DebugAdapterDescriptorFactory {
  createDebugAdapterDescriptor(
    session: vscode.DebugSession,
    executable: vscode.DebugAdapterExecutable | undefined
  ): vscode.ProviderResult<vscode.DebugAdapterDescriptor> {
    const workspaceFolder = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath || process.cwd();
    const adapterScript = path.join(workspaceFolder, 'debug_adapter', 'adapter.py');

    return new vscode.DebugAdapterExecutable('python3', [adapterScript], {
      cwd: workspaceFolder
    });
  }
}

class PantherDebugConfigurationProvider implements vscode.DebugConfigurationProvider {
  provideDebugConfigurations(folder?: vscode.WorkspaceFolder): vscode.ProviderResult<vscode.DebugConfiguration[]> {
    return [
      {
        name: 'PantherLang: F5 Debug Current File',
        type: 'panther',
        request: 'launch',
        program: '${file}',
        cwd: '${workspaceFolder}',
        stopOnEntry: true,
        dryRun: true,
        preLaunchTask: 'PantherLang: Check'
      },
      {
        name: 'PantherLang: Debug Example hello.pan',
        type: 'panther',
        request: 'launch',
        program: '${workspaceFolder}/examples/hello.pan',
        cwd: '${workspaceFolder}',
        stopOnEntry: true,
        dryRun: true,
        preLaunchTask: 'PantherLang: Check Example'
      }
    ];
  }

  resolveDebugConfiguration(
    folder: vscode.WorkspaceFolder | undefined,
    config: vscode.DebugConfiguration
  ): vscode.ProviderResult<vscode.DebugConfiguration> {
    if (!config.type) config.type = 'panther';
    if (!config.request) config.request = 'launch';
    if (!config.name) config.name = 'PantherLang: F5 Debug Current File';
    if (!config.program) config.program = '${file}';
    if (!config.cwd) config.cwd = '${workspaceFolder}';
    if (config.stopOnEntry === undefined) config.stopOnEntry = true;
    if (config.dryRun === undefined) config.dryRun = true;
    if (!config.preLaunchTask) config.preLaunchTask = 'PantherLang: Check';
    return config;
  }
}

export function activate(context: vscode.ExtensionContext) {
  const factory = new PantherDebugAdapterDescriptorFactory();
  const provider = new PantherDebugConfigurationProvider();

  context.subscriptions.push(
    vscode.debug.registerDebugAdapterDescriptorFactory('panther', factory)
  );

  context.subscriptions.push(
    vscode.debug.registerDebugConfigurationProvider('panther', provider)
  );

  context.subscriptions.push(
    vscode.commands.registerCommand('panther.debug.start', async () => {
      const editor = vscode.window.activeTextEditor;
      const program = editor?.document.uri.fsPath || '${file}';
      // compatibility marker for D2 regression: vscode.debug.startDebugging
      return startPantherF5Debug(program);
    })
  );
}

export function deactivate() {}
