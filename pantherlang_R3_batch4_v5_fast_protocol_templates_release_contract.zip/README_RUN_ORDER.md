# PantherLang R3 Fast Repair Bundle

Copy this ZIP into the PantherLang project root and run only from project root.

```bash
cd /home/panther/pantherlang/PantherLang_Developer_Edition_v0_5
unzip pantherlang_R3_batch4_v5_fast_protocol_templates_release_contract.zip
chmod +x bootstrap_R3_batch4_v5_protocol_templates_release_contract.sh
./bootstrap_R3_batch4_v5_protocol_templates_release_contract.sh
python3 -m pytest -q tests/H4_1/test_debug_adapter_core.py tests/test_h4_3_d2_variables_references.py tests/test_h4_3_d3_variable_store.py tests/R3_project_system/test_r3_batch1_part3_templates_professionalization.py tests/R3_project_system/test_r3_batch1_1_1_command_activation_fix.py
python3 -m pytest -q
```

This bundle is flat by design: no nested script path.
