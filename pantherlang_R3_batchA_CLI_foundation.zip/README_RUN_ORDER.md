# R3 Batch A — CLI Foundation

Copy this ZIP to the PantherLang project root, then run only from the project root.

```bash
cd /home/panther/pantherlang/PantherLang_Developer_Edition_v0_5
unzip pantherlang_R3_batchA_CLI_foundation.zip
chmod +x bootstrap_R3_batchA_CLI_foundation.sh
./bootstrap_R3_batchA_CLI_foundation.sh
```

Targeted Batch A regression:

```bash
python3 -m pytest -q \
  tests/phase6_18/test_runtime_bridge.py \
  tests/phase6_19/test_fast_regression.py \
  tests/phase6_20/test_production_readiness.py \
  tests/phase7_2/test_cli_run.py \
  tests/phase7_10/test_final_runtime.py \
  tests/phase9_1/test_production_build.py \
  tests/R3_project_system/test_r3_batch1_part3_templates_professionalization.py \
  tests/R3_project_system/test_r3_batch1_1_1_command_activation_fix.py
```

Then run full regression only after the targeted Batch A tests pass:

```bash
python3 -m pytest -q
```

Expected full regression after Batch A: CLI-related FileNotFoundError failures should disappear. Remaining failures should mostly be DAP/VS Code/variables compatibility for Batch B/C.
