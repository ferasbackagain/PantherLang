# R3 Batch E — Global CLI Wrapper + PantherLang File Icons

Copy this ZIP into the PantherLang repository root, unzip it there, then run:

```bash
cd /home/panther/pantherlang/PantherLang_Developer_Edition_v0_5
unzip pantherlang_R3_batchE_global_CLI_and_file_icons.zip
chmod +x bootstrap_R3_batchE_global_cli_and_file_icons.sh
./bootstrap_R3_batchE_global_cli_and_file_icons.sh
```

Verify:

```bash
hash -r
which panther
panther version
panther check examples/hello.pan
python3 -m pytest -q
```

Rebuild and reinstall VS Code extension:

```bash
cd /home/panther/pantherlang/PantherLang_Developer_Edition_v0_5/vscode-extension
rm -f pantherlang-official-1.1.2.vsix
npx vsce package
code --uninstall-extension pantherlang.pantherlang-official || true
code --install-extension ./pantherlang-official-1.1.3.vsix --force
```

In VS Code:

1. Reload window.
2. Open Settings.
3. Search `File Icon Theme`.
4. Choose `PantherLang Icons`.
