# R3 Batch C3 — VS Code Final Debug Contract Fix

Run from project root only:

```bash
cd /home/panther/pantherlang/PantherLang_Developer_Edition_v0_5
unzip pantherlang_R3_batchC3_VSCode_final_debug_contract_fix.zip
chmod +x bootstrap_R3_batchC3_VSCode_final_debug_contract_fix.sh
./bootstrap_R3_batchC3_VSCode_final_debug_contract_fix.sh
```

Target regression:

```bash
python3 -m pytest -q \
  tests/test_h4_4_d1_vscode_debugger_contribution.py \
  tests/test_h4_4_d2_debug_adapter_registration.py \
  tests/test_h4_4_d4_f5_debug_flow.py \
  tests/test_h4_4_d5_vscode_extension_package_verification.py \
  tests/test_h4_4_d6_vscode_end_to_end_verification.py
```
