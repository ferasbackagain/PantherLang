# R3 Batch F1 — Developer Tooling Final Fixes

Run from PantherLang repository root only:

```bash
cd /home/panther/pantherlang/PantherLang_Developer_Edition_v0_5
unzip pantherlang_R3_batchF1_developer_tooling_final_fixes.zip
chmod +x bootstrap_R3_batchF1_developer_tooling_final_fixes.sh
./bootstrap_R3_batchF1_developer_tooling_final_fixes.sh
python3 -m pytest -q
```

Do not build/release VSIX until full regression passes.
