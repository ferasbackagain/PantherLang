H4_2_FINALIZE_V2 = {
    "f1_core_merge": True,
    "f2_legacy_cleanup": False,
    "f3_dispatcher_merge": False,
    "f4_response_merge": False,
    "f5_event_merge": False,
    "f6_execution_merge": False,
    "f7_regression": False,
    "f8_end_to_end": False,
}
