from .server import DebugServer

class RequestDispatcher:
    def __init__(self):
        self.server=DebugServer()
        self.routes={
            "initialize": lambda a:self.server.initialize(a),
            "configurationDone": lambda a:self.server.configuration_done(),
            "launch": lambda a:self.server.launch(a),
            "terminate": lambda a:self.server.terminate(),
            "disconnect": lambda a:self.server.disconnect(),
        }

    def dispatch(self, request):
        cmd=request["command"]
        if cmd not in self.routes:
            return {"success":False,"message":f"Unsupported command: {cmd}"}
        return self.routes[cmd](request.get("arguments",{}))
