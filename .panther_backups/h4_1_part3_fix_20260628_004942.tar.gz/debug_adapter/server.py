from .capabilities import default_capabilities
from .launcher import PantherProgramLauncher
from .session import DebugSession


class DebugServer:
    def __init__(self, session=None, launcher=None):
        self.session = session or DebugSession()
        self.launcher = launcher or PantherProgramLauncher()

    def initialize(self, arguments=None):
        capabilities = self.session.initialize(arguments or {})
        return {
            "type": "response",
            "command": "initialize",
            "success": True,
            "body": capabilities,
        }

    def configuration_done(self):
        self.session.configuration_done()
        return {
            "type": "response",
            "command": "configurationDone",
            "success": True,
        }

    def launch(self, arguments):
        program = arguments.get("program") if isinstance(arguments, dict) else arguments
        args = arguments.get("args", []) if isinstance(arguments, dict) else []
        cwd = arguments.get("cwd") if isinstance(arguments, dict) else None
        dry_run = arguments.get("dryRun", True) if isinstance(arguments, dict) else True

        launch_info = self.launcher.launch(program, args=args, cwd=cwd, dry_run=dry_run)
        session_info = self.session.launch(program, args=args, cwd=cwd)

        return {
            "type": "event",
            "event": "process",
            "body": {
                "name": program,
                "systemProcessId": launch_info.pid,
                "isLocalProcess": True,
                "startMethod": "launch",
                "state": session_info["state"],
                "command": launch_info.command,
            },
        }

    def terminate(self):
        self.session.terminate()
        return {"type": "event", "event": "terminated"}

    def disconnect(self):
        self.session.disconnect()
        return {"type": "event", "event": "exited", "body": {"exitCode": 0}}
