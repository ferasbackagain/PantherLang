import json
class DAPProtocol:
    @staticmethod
    def decode(data:str):
        return json.loads(data)
    @staticmethod
    def encode(obj):
        return json.dumps(obj)
