from debug_adapter.dispatcher import RequestDispatcher

def test_dispatch_sequence():
    d=RequestDispatcher()
    assert d.dispatch({"command":"initialize","arguments":{}})["success"]
    assert d.dispatch({"command":"configurationDone"})["success"]
    proc=d.dispatch({"command":"launch","arguments":{"program":"main.pan","dryRun":True}})
    assert proc["event"]=="process"
    assert d.dispatch({"command":"terminate"})["event"]=="terminated"
    assert d.dispatch({"command":"disconnect"})["event"]=="exited"

def test_unknown():
    d=RequestDispatcher()
    r=d.dispatch({"command":"xyz"})
    assert r["success"] is False
