from __future__ import annotations

import socket
from pathlib import Path

from .adapter import PantherDebugAdapter
from .transport import SocketTransport, StdioTransport


def run_stdio(root: Path | None = None) -> int:
    return PantherDebugAdapter(StdioTransport(), root=root).serve()


def run_tcp(host: str = "127.0.0.1", port: int = 4711, root: Path | None = None, once: bool = True) -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((host, port))
        server.listen(1)
        while True:
            conn, _addr = server.accept()
            with conn:
                PantherDebugAdapter(SocketTransport(conn), root=root).serve()
            if once:
                return 0
