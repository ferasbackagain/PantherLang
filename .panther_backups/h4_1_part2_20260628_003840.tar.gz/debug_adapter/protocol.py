from __future__ import annotations

import json
from typing import Any, BinaryIO


class DAPProtocolError(RuntimeError):
    pass


def encode_message(message: dict[str, Any]) -> bytes:
    payload = json.dumps(message, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    header = f"Content-Length: {len(payload)}\r\n\r\n".encode("ascii")
    return header + payload


def _readline(stream: BinaryIO) -> bytes:
    line = stream.readline()
    if line == b"":
        raise EOFError("DAP stream closed while reading header")
    return line


def read_message(stream: BinaryIO) -> dict[str, Any]:
    content_length: int | None = None
    while True:
        line = _readline(stream)
        if line in (b"\r\n", b"\n"):
            break
        try:
            key, value = line.decode("ascii").strip().split(":", 1)
        except ValueError as exc:
            raise DAPProtocolError(f"Invalid DAP header line: {line!r}") from exc
        if key.lower() == "content-length":
            content_length = int(value.strip())
    if content_length is None:
        raise DAPProtocolError("Missing Content-Length header")
    payload = stream.read(content_length)
    if len(payload) != content_length:
        raise EOFError("DAP stream closed while reading payload")
    try:
        decoded = json.loads(payload.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise DAPProtocolError("Invalid JSON payload") from exc
    if not isinstance(decoded, dict):
        raise DAPProtocolError("DAP payload must be a JSON object")
    return decoded
