from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class DebugSession:
    """Mutable state for one Panther DAP connection."""

    root: Path = field(default_factory=lambda: Path.cwd())
    initialized: bool = False
    disconnected: bool = False
    client_id: str | None = None
    client_name: str | None = None
    adapter_id: str = "pantherlang"
    lines_start_at_1: bool = True
    columns_start_at_1: bool = True

    @property
    def pid(self) -> int:
        return os.getpid()

    def apply_initialize_arguments(self, arguments: dict[str, Any]) -> None:
        self.client_id = arguments.get("clientID") or arguments.get("clientId")
        self.client_name = arguments.get("clientName")
        self.adapter_id = arguments.get("adapterID", self.adapter_id)
        self.lines_start_at_1 = bool(arguments.get("linesStartAt1", True))
        self.columns_start_at_1 = bool(arguments.get("columnsStartAt1", True))
        self.initialized = True

    def capabilities(self) -> dict[str, Any]:
        return {
            "supportsConfigurationDoneRequest": True,
            "supportsTerminateRequest": True,
            "supportsLoadedSourcesRequest": False,
            "supportsEvaluateForHovers": True,
            "supportsSetVariable": False,
            "supportsRestartRequest": False,
            "supportsStepBack": False,
            "supportsDataBreakpoints": False,
            "supportsInstructionBreakpoints": False,
            "exceptionBreakpointFilters": [],
            "panther": {
                "phase": "H4.1 Part 1",
                "adapter": "Panther Debug Adapter Core",
                "realDAPFraming": True,
            },
        }
