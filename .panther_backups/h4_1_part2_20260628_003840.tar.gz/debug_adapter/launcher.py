from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .server import run_stdio, run_tcp


def doctor() -> int:
    required = ["adapter.py", "protocol.py", "transport.py", "server.py", "launcher.py", "session.py", "messages.py", "__init__.py"]
    base = Path(__file__).resolve().parent
    missing = [name for name in required if not (base / name).exists()]
    payload = {
        "ok": not missing,
        "phase": "H4.1 Part 1",
        "adapter": "Panther Debug Adapter Core",
        "version": __version__,
        "transport": ["stdio", "tcp"],
        "dap_handshake": "initialize -> initialized -> disconnect -> terminated/exited",
        "missing": missing,
    }
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if not missing else 2


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="Panther dap")
    sub = parser.add_subparsers(dest="cmd", required=True)

    start_p = sub.add_parser("start")
    start_p.add_argument("--stdio", action="store_true", help="Run DAP over stdio. Default.")
    start_p.add_argument("--tcp", action="store_true", help="Run DAP over TCP.")
    start_p.add_argument("--host", default="127.0.0.1")
    start_p.add_argument("--port", type=int, default=4711)

    sub.add_parser("doctor")
    sub.add_parser("version")

    args = parser.parse_args(argv)
    if args.cmd == "doctor":
        return doctor()
    if args.cmd == "version":
        print(__version__)
        return 0
    if args.cmd == "start":
        if args.tcp:
            return run_tcp(args.host, args.port, root=Path.cwd())
        return run_stdio(root=Path.cwd())
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
