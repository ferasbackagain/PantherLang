from debug_adapter.dispatcher import RequestDispatcher


def boot_launched_dispatcher():
    dispatcher = RequestDispatcher()
    assert dispatcher.dispatch({"seq": 1, "type": "request", "command": "initialize", "arguments": {}})["success"]
    assert dispatcher.dispatch({"seq": 2, "type": "request", "command": "configurationDone"})["success"]
    launched = dispatcher.dispatch({
        "seq": 3,
        "type": "request",
        "command": "launch",
        "arguments": {"program": "examples/hello.pan", "dryRun": True},
    })
    assert launched["event"] == "process"
    assert launched["body"]["execution"]["status"] == "ready"
    return dispatcher


def test_dap_continue_pause_stop_terminate_routing():
    dispatcher = boot_launched_dispatcher()
    assert dispatcher.dispatch({"seq": 4, "type": "request", "command": "continue", "arguments": {"threadId": 1}})["body"]["status"] == "running"
    paused = dispatcher.dispatch({"seq": 5, "type": "request", "command": "pause", "arguments": {"threadId": 1}})
    assert paused["event"] == "stopped"
    assert paused["body"]["status"] == "paused"
    assert dispatcher.dispatch({"seq": 6, "type": "request", "command": "continue", "arguments": {"threadId": 1}})["body"]["status"] == "running"
    stopped = dispatcher.dispatch({"seq": 7, "type": "request", "command": "stop", "arguments": {"threadId": 1}})
    assert stopped["event"] == "stopped"
    assert stopped["body"]["status"] == "stopped"
    assert dispatcher.dispatch({"seq": 8, "type": "request", "command": "terminate"})["event"] == "terminated"


def test_execution_commands_are_supported():
    dispatcher = RequestDispatcher()
    for command in ("continue", "pause", "stop"):
        response = dispatcher.dispatch({"seq": 10, "type": "request", "command": command})
        assert response.get("success") is not False
