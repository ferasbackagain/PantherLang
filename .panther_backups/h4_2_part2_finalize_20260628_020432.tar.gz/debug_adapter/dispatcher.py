from .server import DebugServer


class RequestDispatcher:
    def __init__(self, server=None):
        self.server = server or DebugServer()
        self.routes = {
            "initialize": self._initialize,
            "configurationDone": self._configuration_done,
            "setBreakpoints": self._set_breakpoints,
            "launch": self._launch,
            "terminate": self._terminate,
            "disconnect": self._disconnect,
            "continue": self._continue,
            "pause": self._pause,
            "stop": self._stop,
        }

    def dispatch(self, request):
        if not isinstance(request, dict):
            return self._error(None, None, "request must be a dictionary")

        command = request.get("command")
        seq = request.get("seq")

        if not command:
            return self._error(seq, None, "missing DAP command")

        handler = self.routes.get(command)
        if handler is None:
            return self._error(seq, command, f"Unsupported command: {command}")

        try:
            response = handler(request.get("arguments", {}))
            return self._normalize_response(seq, command, response)
        except Exception as exc:
            return self._error(seq, command, str(exc))

    def _initialize(self, arguments):
        return self.server.initialize(arguments or {})

    def _configuration_done(self, arguments):
        return self.server.configuration_done()

    def _set_breakpoints(self, arguments):
        return self.server.set_breakpoints(arguments or {})

    def _launch(self, arguments):
        return self.server.launch(arguments or {})

    def _continue(self, arguments):
        return self.server.continue_execution(arguments or {})

    def _pause(self, arguments):
        return self.server.pause(arguments or {})

    def _stop(self, arguments):
        return self.server.stop(arguments or {})

    def _terminate(self, arguments):
        return self.server.terminate()

    def _disconnect(self, arguments):
        return self.server.disconnect()

    def _normalize_response(self, request_seq, command, response):
        if not isinstance(response, dict):
            return {
                "type": "response",
                "request_seq": request_seq,
                "command": command,
                "success": True,
                "body": response,
            }

        if response.get("type") == "response":
            response.setdefault("request_seq", request_seq)
            response.setdefault("command", command)
            response.setdefault("success", True)
            return response

        response.setdefault("request_seq", request_seq)
        response.setdefault("sourceCommand", command)
        return response

    def _error(self, request_seq, command, message):
        return {
            "type": "response",
            "request_seq": request_seq,
            "command": command,
            "success": False,
            "message": message,
        }
