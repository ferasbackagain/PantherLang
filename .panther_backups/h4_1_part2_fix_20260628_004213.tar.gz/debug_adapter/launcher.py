import subprocess
class Launcher:
    def launch(self, command):
        return subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
