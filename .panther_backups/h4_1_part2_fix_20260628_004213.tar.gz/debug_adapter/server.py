from .session import DebugSession
class DebugServer:
    def __init__(self):
        self.session=DebugSession()
    def initialize(self):
        self.session.initialize({"supportsConfigurationDoneRequest":True})
        return {"type":"response","command":"initialize","success":True}
    def launch(self, program):
        self.session.launch(program)
        return {"type":"event","event":"process","state":self.session.state}
    def terminate(self):
        self.session.terminate()
        return {"type":"event","event":"terminated"}
