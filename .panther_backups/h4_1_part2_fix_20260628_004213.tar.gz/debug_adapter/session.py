class DebugSession:
    def __init__(self):
        self.state="created"
        self.capabilities={}
    def initialize(self, caps=None):
        self.capabilities=caps or {}
        self.state="initialized"
    def launch(self, program):
        self.program=program
        self.state="running"
    def terminate(self):
        self.state="terminated"
