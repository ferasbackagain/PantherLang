from debug_adapter.server import DebugServer
def test_lifecycle():
    s=DebugServer()
    assert s.initialize()["success"]
    assert s.launch("demo")["state"]=="running"
    assert s.terminate()["event"]=="terminated"
