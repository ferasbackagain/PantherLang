from .breakpoints import BreakpointManager
from .capabilities import default_capabilities
from .launcher import PantherProgramLauncher
from .session import DebugSession
from .source_map import PantherSourceMap


class DebugServer:
    def __init__(self, session=None, launcher=None, breakpoint_manager=None, source_map=None):
        self.session = session or DebugSession()
        self.launcher = launcher or PantherProgramLauncher()
        self.source_map = source_map or PantherSourceMap()
        self.breakpoint_manager = breakpoint_manager or BreakpointManager()

    def initialize(self, arguments=None):
        capabilities = self.session.initialize(arguments or {})
        capabilities.update({
            "supportsConfigurationDoneRequest": True,
            "supportsTerminateRequest": True,
            "supportsHitConditionalBreakpoints": True,
            "supportsConditionalBreakpoints": True,
            "supportsLogPoints": True,
        })
        return {
            "type": "response",
            "command": "initialize",
            "success": True,
            "body": capabilities,
        }

    def configuration_done(self):
        self.session.configuration_done()
        return {
            "type": "response",
            "command": "configurationDone",
            "success": True,
        }

    def set_breakpoints(self, arguments):
        arguments = arguments or {}
        source = arguments.get("source") or {}
        source_path = source.get("path") if isinstance(source, dict) else source
        raw_breakpoints = arguments.get("breakpoints", [])
        source_modified = bool(arguments.get("sourceModified", False))

        if not source_path:
            return {
                "type": "response",
                "command": "setBreakpoints",
                "success": False,
                "message": "setBreakpoints requires source.path",
                "body": {"breakpoints": []},
            }

        # Register the source if it exists. If it does not exist yet, the manager still
        # accepts the path so VS Code can set pending breakpoints before build/run.
        try:
            self.source_map.register_file(source_path, require_exists=False)
        except Exception:
            pass

        adjusted = []
        for raw in raw_breakpoints:
            requested_line = raw.get("line") if isinstance(raw, dict) else raw
            item = dict(raw) if isinstance(raw, dict) else {"line": requested_line}
            try:
                resolved_line, verified, message = self.source_map.resolve_breakpoint_line(source_path, requested_line, require_exists=False)
                item["line"] = resolved_line
                item["_verified"] = verified
                item["_message"] = message
            except Exception as exc:
                item["_verified"] = False
                item["_message"] = str(exc)
            adjusted.append(item)

        breakpoints = self.breakpoint_manager.set_breakpoints(source_path, adjusted, require_exists=False)
        for breakpoint, item in zip(breakpoints, adjusted):
            if "_verified" in item:
                breakpoint.verified = bool(item["_verified"])
            if item.get("_message"):
                breakpoint.message = item["_message"]

        return {
            "type": "response",
            "command": "setBreakpoints",
            "success": True,
            "body": {
                "breakpoints": [bp.to_dap() for bp in breakpoints],
                "sourceModified": source_modified,
            },
        }

    def launch(self, arguments):
        program = arguments.get("program") if isinstance(arguments, dict) else arguments
        args = arguments.get("args", []) if isinstance(arguments, dict) else []
        cwd = arguments.get("cwd") if isinstance(arguments, dict) else None
        dry_run = arguments.get("dryRun", True) if isinstance(arguments, dict) else True

        launch_info = self.launcher.launch(program, args=args, cwd=cwd, dry_run=dry_run)
        session_info = self.session.launch(program, args=args, cwd=cwd)

        return {
            "type": "event",
            "event": "process",
            "body": {
                "name": program,
                "systemProcessId": launch_info.pid,
                "isLocalProcess": True,
                "startMethod": "launch",
                "state": session_info["state"],
                "command": launch_info.command,
            },
        }

    def terminate(self):
        self.session.terminate()
        return {"type": "event", "event": "terminated"}

    def disconnect(self):
        self.session.disconnect()
        return {"type": "event", "event": "exited", "body": {"exitCode": 0}}
