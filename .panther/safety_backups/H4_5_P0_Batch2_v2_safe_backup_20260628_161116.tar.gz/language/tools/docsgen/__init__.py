from .docgen import PantherDocGenerator
