# R3 Batch B — DAP Compatibility

Run from project root only.

```bash
cd /home/panther/pantherlang/PantherLang_Developer_Edition_v0_5
unzip pantherlang_R3_batchB_DAP_compatibility.zip
chmod +x bootstrap_R3_batchB_DAP_compatibility.sh
./bootstrap_R3_batchB_DAP_compatibility.sh
```

Targeted regression:

```bash
python3 -m pytest -q \
  tests/H4_1/test_debug_adapter_core.py \
  tests/P3_atomic_replacement/test_p3_batch6_production_debug_adapter.py \
  tests/test_h4_2_finalize_v2_f*.py \
  tests/test_h4_2_f5*.py \
  tests/test_h4_2_part*.py \
  tests/test_h4_3_d*.py \
  tests/test_h4_finalize.py \
  tests/test_h4_part2.py \
  tests/test_h4_part3.py
```

Then full regression:

```bash
python3 -m pytest -q
```
